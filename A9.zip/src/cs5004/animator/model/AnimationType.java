package cs5004.animator.model;

/**
 * An enum to represent an animation type.
 */
public enum AnimationType {
  MOVE, CHANGECOLOR, SCALE;
}
